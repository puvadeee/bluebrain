from distutils.core import setup

setup(
    name='Cannybots',
    version='0.1dev',
    packages=['cannybots',],
    license='MIT license',
    long_description=open('README.txt').read(),
)
